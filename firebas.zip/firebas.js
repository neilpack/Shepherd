// firebase.js
// Import Firebase SDKs through script tags in your HTML, not modules.

const firebaseConfig = {
  apiKey: "AIzaSyCg9gfDXKxFG0TFqGHTuW1Qa9e7JKLA-88",
  authDomain: "shepherd-2a626.firebaseapp.com",
  projectId: "shepherd-2a626",
  storageBucket: "shepherd-2a626.firebasestorage.app",
  messagingSenderId: "332680210554",
  appId: "1:332680210554:web:7066dd649659efa69a33c3",
  measurementId: "G-11EDRK7V3L"
};

// Initialize Firebase (classic syntax, matching your HTML imports)
firebase.initializeApp(firebaseConfig);
