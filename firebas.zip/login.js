
// login.js
const form = document.getElementById("form");
const errorMsg = document.getElementById("error-message");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  firebase.auth().signInWithEmailAndPassword(email, password)
    .then(() => {
      alert("Login successful!");
      window.location.href = "dashboard.html"; // protected page
    })
    .catch((error) => {
      errorMsg.textContent = error.message;
      errorMsg.style.color = "red";
    });
});
